package com.niit.SpringExample;

public class Engine {
	private String engineName ="HJOIU";

	
	Engine()
	{
		
	}


	public String getEngineName() {
		return engineName;
	}


	public void setEngineName(String engineName) {
		this.engineName = engineName;
	}
	

}
